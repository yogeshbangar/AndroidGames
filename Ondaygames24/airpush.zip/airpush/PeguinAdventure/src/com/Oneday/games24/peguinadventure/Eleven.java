package com.Oneday.games24.peguinadventure;

public class Eleven {
	boolean isTuch=false;
	byte no;
	void set(int _no)
	{
		no = (byte)_no;
		isTuch=false;
	}
}

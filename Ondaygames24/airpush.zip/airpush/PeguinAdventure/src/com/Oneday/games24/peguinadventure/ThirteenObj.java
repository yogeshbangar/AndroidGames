package com.Oneday.games24.peguinadventure;

public class ThirteenObj {
	int no;
	float x,y;
	
	void set(float _x,float _y,int _no)
	{
		x =_x;
		y = _y;
		no =_no;
	}
}

package com.onedaygames24.pokernpoker;
import com.qfzikeef.iqrcfcmi148442.AdListener;

public class AirBannerListener  implements AdListener.BannerAdListener{

	@Override
	public void noAdAvailableListener() {
		// TODO Auto-generated method stub
		System.out.println("   noAdAvailableListener     ");
	}

	@Override
	public void onAdClickListener() {
		// TODO Auto-generated method stub
		System.out.println("   onAdClickListener     ");
	}

	@Override
	public void onAdExpandedListner() {
		// TODO Auto-generated method stub
		System.out.println("   onAdExpandedListner     ");
	}

	@Override
	public void onAdLoadedListener() {
		// TODO Auto-generated method stub
		System.out.println("   onAdLoadedListener     ");
	}

	@Override
	public void onAdLoadingListener() {
		// TODO Auto-generated method stub
		System.out.println("   onAdLoadingListener     ");
	}

	@Override
	public void onCloseListener() {
		// TODO Auto-generated method stub
		System.out.println("   onCloseListener     ");
	}

	@Override
	public void onErrorListener(String arg0) {
		// TODO Auto-generated method stub
		System.out.println("   onErrorListener     ");
	}

	
}

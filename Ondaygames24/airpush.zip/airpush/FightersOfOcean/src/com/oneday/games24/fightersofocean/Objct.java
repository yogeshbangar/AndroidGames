package com.oneday.games24.fightersofocean;

public class Objct {
	float x,y;
	void set(float _x,float _y)
	{
		x =_x;
		y =_y;
	}
}

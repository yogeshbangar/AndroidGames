/** Automatically generated file. DO NOT MODIFY */
package com.oneday.games24.fightersofocean;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
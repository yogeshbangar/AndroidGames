package com.oneday.games24.santafreerunner;

public class Smoke {
	float x,y;
	int i;
	void set(float _x,float _y,int _i)
	{
		x =_x;
		y =_y;
		i =_i;
	}
}

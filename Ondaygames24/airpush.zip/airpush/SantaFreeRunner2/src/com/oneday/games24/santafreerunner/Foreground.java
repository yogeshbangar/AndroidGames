package com.oneday.games24.santafreerunner;

public class Foreground {
	float x,y;
	int p;
	void set(float _x,float _y,int _p)
	{
		x = _x;
		y = _y;
		p = _p;
	}
}

package com.oneday.games24.santafreerunner;

public class Background {
	float x,y;
	void set(float _x,float _y)
	{
		x = _x;
		y = _y;
	}
}

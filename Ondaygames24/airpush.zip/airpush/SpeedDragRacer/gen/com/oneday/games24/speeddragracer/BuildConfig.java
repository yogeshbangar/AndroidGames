/** Automatically generated file. DO NOT MODIFY */
package com.oneday.games24.speeddragracer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
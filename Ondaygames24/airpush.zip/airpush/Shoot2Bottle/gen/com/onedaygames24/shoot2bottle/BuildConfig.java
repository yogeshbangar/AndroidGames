/** Automatically generated file. DO NOT MODIFY */
package com.onedaygames24.shoot2bottle;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
package org.rajawali3d.loader;

public interface IParser {

	public IParser parse() throws ParsingException;
}

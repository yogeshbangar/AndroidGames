package org.rajawali3d.loader.awd;

import org.rajawali3d.materials.Material;

public abstract class ATextureBlockParser extends ABlockParser {

	public abstract Material getMaterial();

}

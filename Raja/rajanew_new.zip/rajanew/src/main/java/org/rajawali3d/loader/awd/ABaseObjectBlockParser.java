package org.rajawali3d.loader.awd;

import org.rajawali3d.Object3D;

public abstract class ABaseObjectBlockParser extends ABlockParser {

	public abstract Object3D getBaseObject3D();

}

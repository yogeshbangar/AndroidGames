package rajawali.parser.awd;

public abstract class AExportableBlockParser extends ABaseObjectBlockParser {

}

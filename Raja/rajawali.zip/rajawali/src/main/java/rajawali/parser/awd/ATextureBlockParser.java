package rajawali.parser.awd;

import rajawali.materials.Material;

public abstract class ATextureBlockParser extends ABlockParser {

	public abstract Material getMaterial();

}
